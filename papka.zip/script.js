/* ====== SOZLAMALAR (o'zgartirsa bo'ladi) ====== */
const MATN = "I love you";                         // yurakdagi yozuv
const EMOJILAR = ["💖","💕","😍","🥰","💘","🌹","✨","😘","💗","🦋"]; // chiqadigan emojilar
const RANG = "255, 90, 130";                        // yozuv rangi (R, G, B)
const TEZLIK = 0.012;                               // aylanish tezligi
/* ============================================== */

const canvas = document.getElementById("heart");
const ctx = canvas.getContext("2d");
let W, H;
function resize() {
  W = canvas.width = innerWidth;
  H = canvas.height = innerHeight;
}
addEventListener("resize", resize);
resize();

// Yurak nuqtalari (qatlam-qatlam, qalinligi bor)
const nuqtalar = [];
const QATLAM = 14;
for (let k = 0; k < QATLAM; k++) {
  const s = 1 - k * 0.055;            // ichkariga qarab kichrayadi
  const z = (k - QATLAM / 2) * 1.6;   // qalinlik
  for (let i = 0; i < 70; i++) {
    const t = (i / 70) * Math.PI * 2;
    const x = 16 * Math.pow(Math.sin(t), 3);
    const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
    nuqtalar.push({ x: x * s, y: y * s, z: z });
  }
}

let burchak = 0;
function chiz() {
  ctx.fillStyle = "rgba(0,0,0,0.25)";   // iz qoldirish effekti
  ctx.fillRect(0, 0, W, H);

  burchak += TEZLIK;
  const cos = Math.cos(burchak), sin = Math.sin(burchak);
  const olcham = Math.min(W, H) / 40;
  const urish = 1 + 0.04 * Math.sin(Date.now() / 200); // yurak urishi

  const tayyor = nuqtalar.map(p => {
    const x = (p.x * cos - p.z * sin) * urish;
    const z = (p.x * sin + p.z * cos);
    return { x: x * olcham + W / 2, y: p.y * urish * olcham + H / 2, z: z };
  }).sort((a, b) => a.z - b.z);          // orqadagilar avval chiziladi

  ctx.textAlign = "center";
  for (const p of tayyor) {
    const chuqurlik = (p.z + 20) / 40;   // 0..1
    const a = Math.max(0.15, Math.min(1, chuqurlik));
    ctx.font = `${Math.round(8 + a * 9)}px Arial`;
    ctx.fillStyle = `rgba(${RANG}, ${a})`;
    ctx.fillText(MATN, p.x, p.y);
  }
  requestAnimationFrame(chiz);
}
chiz();

// Suzib chiqadigan emojilar
const emojiBox = document.getElementById("emojis");
function emojiChiqar(x) {
  const el = document.createElement("span");
  el.className = "emoji";
  el.textContent = EMOJILAR[Math.floor(Math.random() * EMOJILAR.length)];
  el.style.left = x + "px";
  el.style.fontSize = 20 + Math.random() * 30 + "px";
  el.style.setProperty("--dx", (Math.random() * 160 - 80) + "px");
  el.style.setProperty("--rot", (Math.random() * 60 - 30) + "deg");
  el.style.animationDuration = 4 + Math.random() * 4 + "s";
  emojiBox.appendChild(el);
  setTimeout(() => el.remove(), 8500);
}
setInterval(() => emojiChiqar(Math.random() * innerWidth), 350);

// Bosganda ko'proq emoji
addEventListener("pointerdown", e => {
  for (let i = 0; i < 8; i++) setTimeout(() => emojiChiqar(e.clientX + (Math.random() * 80 - 40)), i * 60);
});
